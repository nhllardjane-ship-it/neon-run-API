# NeonRun — compilation APK avec GitHub Actions

1. Crée un dépôt GitHub.
2. Envoie tous les fichiers de ce projet dans le dépôt.
3. Va dans l'onglet **Actions**.
4. Sélectionne **Build NeonRun APK**.
5. Clique sur **Run workflow**.
6. Quand le workflow est terminé avec une coche verte, ouvre l'exécution.
7. Dans **Artifacts**, télécharge **NeonRun-APK**.
8. Décompresse l'archive pour récupérer `app-debug.apk`.

Le workflow utilise Java 17, Node.js 20 et Gradle Wrapper du projet. Le build utilise `assembleDebug`, qui produit un APK de test installable sur Android.
